//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
print(str)


//classes ans structures in swift

//declaring a structure
struct project{
    var title = ""
    var hours = 0
    func display(){
        print("project title :", title)
         print("total hours :", hours)
    }
}
 //declaring instance of structure
var LMSProject = project(title: "Moodle",hours :200)
print(LMSProject)

LMSProject.display()
LMSProject.hours=300
LMSProject.display()



//class declaration
class manager{
    var name : String = ""
    var productowner : Bool = true
    var currentprojects = project()
}

//creating instance of class
let mgrcanada = manager()
mgrcanada.name = "blah"
mgrcanada.productowner = true
mgrcanada.currentprojects = project(title: "sales reporter", hours:20)

print("",mgrcanada.name)
print("",mgrcanada.productowner)
print("",mgrcanada.currentprojects.title)
print("",mgrcanada.currentprojects.hours)

mgrcanada.currentprojects.title = "manager"
mgrcanada.currentprojects.hours = 49


print("",mgrcanada.name)
print("",mgrcanada.productowner)
print("",mgrcanada.currentprojects.title)
print("",mgrcanada.currentprojects.hours)



//structure of value types



//classes are refrence type
class institute{
    var street = "265 yorkland blvd"
    var city = "north york"
    var postalcode = "M1H1Y1"
}

var mylambton = institute()
print("mylambton street name",mylambton.street)
print("mylambton city name",mylambton.city)
print("mylambton postal code",mylambton.postalcode)



var mycestar = mylambton
print("mylambton street name",mycestar.street)
print("mylambton city name",mycestar.city)
print("mylambton postal code",mycestar.postalcode)


// updation will occcur in both instances
mycestar.city = "brampton"
mycestar.postalcode = "b4bh4j"

print("mylambton street name",mylambton.street)
print("mylambton city name",mylambton.city)
print("mylambton postal code",mylambton.postalcode)

print("mylambton street name",mycestar.street)
print("mylambton city name",mycestar.city)
print("mylambton postal code",mycestar.postalcode)


//identical to ===
if mylambton === mycestar{
    print("same lambton and cestar")
}
else{
    print(" not same lambton and cestar")
}

//new instance
var yourcestar = institute()
if yourcestar === mycestar{
    print("same lambton and cestar")
}
else{
    print(" not same lambton and cestar")
}


//task







