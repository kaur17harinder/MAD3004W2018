//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"


//dictionaries

var namesOfIntegers = [Int: String]() //nameofintergers is an empty [int:srtring]dictionary
namesOfIntegers[16] = "sixteen" // nameofintegers now contains one key value pair
print("namesOfIntegers : \(namesOfIntegers)")

namesOfIntegers = [:]//names of dictionary is once again empty dictiobnary of type[int:string]
print("dictionary contains \(namesOfIntegers.count) elements")
namesOfIntegers[28] = "Twenty eight "

print("dictionary contains \(namesOfIntegers.count) elements")
print("namesOfIntegers : ",namesOfIntegers)

if namesOfIntegers.isEmpty{
    print("dictionary is empty")
}
else{
    print("dictionary is not empty")
}


//another example of dictionary
var airports: [String:String] = ["YYZ": "toronto pearson", "DUB": "dublin"]
print("airports: \(airports)")
print(" the airport dictionary contains \(airports.count) items")

//adding value
airports["LHR"] = "London Heathrow"
//adding and updating
airports["YYZ"] = "tp international"
airports["AMD"] = "SVP INTERNATIONAL"
print("airports: \(airports)")


//old value and other way of updating
//if (if) is not here then warning of interpolation willl arise that means if it contains null value what it would print
let oldValue = airports.updateValue("Dublin Airport", forKey: "DUB")
print("The old value for DUB was \(oldValue) ")

//FIND THE KEY VALUE AND IF MATCHES IT WILL BE PRINTED
if let airportName = airports["AMD"] {
    print("airports: \(airports)")
    print("The name of the airport is \(airportName).")
} else {
    print("That airport is not in the airports dictionary.")
}

//DELETING VALUES:VALUE CAN BE DELETED BY USING NIL
airports["APL"] = "Apple International"
print("airports: \(airports)")
// "Apple International" is not the real airport for APL, so delete it
airports["APL"] = nil
// APL has now been removed from the dictionary
print("airports: \(airports)")




if let removedValue = airports.removeValue(forKey: "DUB") {
    print("The removed airport's name is \(removedValue).")
} else {
    print("The airports dictionary does not contain a value for DUB.")
}
// Prints "The removed airport's name is Dublin Airport."
print("airports: \(airports)")



//FOR LOOP
//ACCESING KEYS AND VALUES USING FOR LOOP
for (airportCode, airportName) in airports {
    print("\(airportCode): \(airportName)")
}

//OTHER WAY OF ACCESSING
for airportCode in airports.keys {
    print("Airport code: \(airportCode)")
    
    for airportName in airports.values {
        print("Airport name: \(airportName)")
    }
}
//<KEY,VALUE> PAIRS



//task day 3
var person = [String:AnyObject]()
person["first name"] = "harry" as AnyObject
person["last name"] = "potter" as AnyObject
person["age"] = Int(50) as AnyObject
//person["address"]=
person[" total amount"] = Int(2000) as AnyObject
print("person : " ,person)




//
    var d1 : Dictionary<String,String> = ["india":"hindi","canada":"english"]
    print(d1)
    print(d1.description)
    print(d1["india"]!)
    print(d1["canada"]!)//exclamation sign use for wrapping
    //print(d1["USA"]!)//if you
    d1["china"] = "mandarin"
    for (k,v) in d1{
        print("\(k) -> \(v)")
    }

var d2 = ["india":"hindi","canada":"english"]
for (k,v) in d2{
    print("\(k) -> \(v)")
}

//dictionary with any value types
var d3 = [String: AnyObject]()
d3["first name"] = "harry" as AnyObject
d3["last name"] = "potter" as AnyObject
d3["age"] = Int(50) as AnyObject
d3["salary"] = nil

print("d3",d3)

//getting as akey ,value pair
for(k,v) in d3{
    print("\(k) -> \(v)")
}

//declaring tuples
var x = (10,20,"harry")
print(x.0)
print(x.1)
print(x.2)

let http404error = (404, "not found")
print(http404error)

let (statuscode, statusmessage) = http404error
print("statuscode:", statuscode)
print("statusmessage:", statusmessage)
//print the code only and _ is used to ignore because we hve todefine all values
let(codeonly,_)=http404error
print("codeonly:", codeonly)

let errordescription = (code : 404 ,message : "not found")
print(errordescription.code,errordescription.message)





