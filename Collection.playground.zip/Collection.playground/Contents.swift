//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

//Array declaration
var a = [10,20,30,40,50]
print("a[0]: \(a[0])")
print("a : ",a)

let j1 = [10,20]
print("j1 :",j1)

//use methods to add values
var b = [Int]();
print("size of array b: \(b.count)")
b.append(100)
print("b[0] : \(b[0])")

b.append(1000)
print("b :", b)

b[0]=1000
print("b[0] : \(b[0])")

/* index out of range error
b[2]=500
print("b :", b)
print("size of array b: \(b.count)")
*/

//assigning default values
var num1 = [Int](repeating: 1,count: 3)
print("num1 array: \(num1)")
var num2 = [Int](repeating: 5,count: 3)
print("num2 array: \(num2)")
var numMerge = num1 + num2
print("merge array: \(numMerge)")


//declare to store any types values
var c=[Any]()
print("size of array c : \(c.count)")
c.append(100)
c.append("patel")
c.append(100.23)
print("c array : \(c)")

var x = a[1...3]
for t in x{
    print("x: \(t)")
}


//string array and for each with (key,value)
var shoppingList : [String] = ["eggs","milk"]
for(index,value) in shoppingList.enumerated(){
    print("item \(index):\(value)")
}
print("shoppinglist array :\(shoppingList)")

if shoppingList.isEmpty{
    print("empty list")
}
else{
    print("not empty list")
}

//adding value to list
shoppingList.append("flour")
print("shoppinglist array :\(shoppingList)")

//adding values
shoppingList += ["chocolate","cheese","butter"]
print("shoppinglist array :\(shoppingList)")
shoppingList.insert("maple" ,at: 0)
let maple = shoppingList.remove(at:2)
//print(maple)
//removing last value
let apples = shoppingList.removeLast()
print("shoppinglist array :\(shoppingList)")




//SET COLLECTION
var grades : Set<Character> = []
grades.insert("A")
grades.insert("B")
print("grades : \(grades)")
print("grades no of elements",grades.count)

//set takes only hashable values like int , double,boolean,char
//var gradetype : set <Any> = []

var favoritegenres: Set<String> = ["rock","hiphop","jazz"]
print("favouritegenres : \(favoritegenres)")

print (" i have \(favoritegenres.count) fvaourite music genres..")
if favoritegenres.isEmpty {
    print("As far as music goes, I'm not picky.")
} else {
    print("I have particular music preferences.")
}
//in
favoritegenres.insert("blah blah")
print("favouritegenres : \(favoritegenres)")


if let removedgenre = favoritegenres.remove("rock") {
    print("\(removedgenre)? I'm over it.")
} else {
    print("I never much cared for that.")
}

//sorting
for genre in favoritegenres.sorted() {
    print("\(genre)")
}
//set operations
let oddDigits: Set = [1, 3, 5, 7, 9]
let evenDigits: Set = [0, 2, 4, 6, 8]
let singleDigitPrimeNumbers: Set = [2, 3, 5, 7]

print(oddDigits.union(evenDigits).sorted())

print(oddDigits.intersection(evenDigits).sorted())

print(oddDigits.subtracting(singleDigitPrimeNumbers).sorted())

print(oddDigits.symmetricDifference(singleDigitPrimeNumbers).sorted())

//set equality(subset,superset,disjoint)
let houseAnimals: Set = ["🐶", "🐱"]
let farmAnimals: Set = ["🐮", "🐔", "🐑", "🐶", "🐱"]
let cityAnimals: Set = ["🐦", "🐭"]

print(houseAnimals.isSubset(of: farmAnimals))

print(farmAnimals.isSuperset(of: houseAnimals))

print(farmAnimals.isDisjoint(with: cityAnimals))


