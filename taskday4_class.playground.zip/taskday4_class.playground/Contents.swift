//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"



struct address
{
    var street = "braidwood lake"
    var area  = "brampton"
    var postalcode = "l6z4l9"
}
class person{
    var firstname : String = " "
    var lastname : String = " "
    var age :  Int = 0
    var address1 = address()
    var totalamount : Int = 0
}

var person1 = person()
person1.firstname = "Harinder"
person1.lastname = "kaur"
person1.age = 21
person1.address1 = address()
person1.totalamount = 9000



print("first name of the person :",person1.firstname)
print("last name of the person :",person1.lastname)
print("age of the person :",person1.age)
print("address of the person : ",person1.address1)
print("total amount of the person : ",person1.totalamount)
