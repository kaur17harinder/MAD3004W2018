//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

print(str)
//for multiple lines in string
let strOne = """

this is first line
this is another line
this is third line
ok last line
"""

print(strOne)

// checking whether string is empty or not

var mood = ""
let heart = "\u{1F496}"//unicode

mood = "happy"
if mood.isEmpty{
    print("blah blah")
}
else{
    print(heart)
}


//redefining
mood += "cheerful and excited"
print(mood)

//heart += "be happy" its constant declared by let


//appending with string
var firstname = String()
firstname = "harry"
print(firstname)

for i in firstname{
    print(i)
    
}
//adding charcater to the string
let initial : Character = "h"
firstname.append(initial)

print(firstname)
//counting length of thr string
print("firstname is \(firstname) which is \(firstname.count) character long.")


//various other method of concatenation
let string1 = "treat you better"
let string2 = "end game"
var string3 = string1 + string2
print(string3)

var string4 = "the heart wants what it wants"
string4 += string2
print(string4)

//index
print("start Index:", firstname[firstname.startIndex])
//print("")last index is null
print("before end index:",firstname[firstname.index(before: firstname.endIndex)])
print("after start index:",firstname[firstname.index(after: firstname.startIndex)])
print("5th charcater:",firstname[firstname.index(firstname.startIndex,offsetBy:4)])
print("3rd from last:",firstname[firstname.index(firstname.endIndex,offsetBy: -3)])

/*
//count the string ,run the for loop and display ist to last then reverse
var name = String()
name = "harinder"
var count=0
count=name.count
print("name is \(name) which is \(name.count) character long.")
print(count)
for count in name{
   print(count)
}
*/


var idx=firstname.index(firstname.startIndex,offsetBy: 3)
print("fourth character:",firstname[idx])

var language = "swift"
print("language:",language)

language.insert("!",at:language.endIndex)
print("language:",language)

language.insert(contentsOf : "java" , at:language.endIndex)//content is used for entering a string into string
print("language:",language)

language.insert(contentsOf : "is nice than " , at:language.index(language.startIndex,offsetBy:6))
print("language contentsOf:",language)

language.remove(at:language.index(before: language.endIndex))
print("language remove :",language)

let range = language.startIndex..<language.endIndex
language.removeSubrange(range)
print("language removesubrange:",language)

let greeting = "happy holidays"
let index = greeting.index(of: " ") ?? greeting.endIndex
let beginning = greeting[..<index]
let newgreet = String(beginning)
print(newgreet)


//upper andlower cases
print("sub string:",newgreet)
print("string in uppercase :",newgreet.uppercased())
if(newgreet == newgreet.uppercased()){
    print("equal")
}
else{
    print(" not equal")
}


//grades evaluation
var grade : String?
//grade = "a"

let finalgrade = grade ?? "f"

if (finalgrade.isEmpty){
    print(" not graded yet")
}
else{
    print(" grade:",finalgrade)
}



