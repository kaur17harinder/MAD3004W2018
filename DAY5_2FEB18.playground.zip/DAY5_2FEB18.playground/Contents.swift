//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

//CLASSES
class employee
{
    var empID: Int?
    var empName: String?
    var basicPay: Double?
    
    //intializers
    init(){
        self.empID = 0
        self.empName = ""
        self.basicPay = 0.0
    }
    //parameterized initializer
    init(ID: Int, nm: String, pay: Double){
        self.empID = ID
        self.empName = nm
        self.basicPay = pay
    }
    
    func display(){
        print("employee ID :",self.empID!)
        print("employee NAME :",self.empName!)
        print("employee BASIC PAY :",self.basicPay!)
    }
    //deinitializers
    
}
//object of employee class
var emp1 = employee()
emp1.empID = 122
emp1.empName = "jack"
emp1.basicPay = 5000
emp1.display()

//inherited  class
class permanentemployee : employee{ //employee is added to showthat it is inheriting its properties
    var vacationweeks : Int?
    
    //default intializer
    override init() {
        super.init()
        self.vacationweeks = 0
    }
    //parameterized initializer of sub classes
    init(eID: Int, enm: String, epay: Double, evw: Int){
        super.init(ID : eID, nm : enm, pay : epay)
       self.vacationweeks = evw
    }
    override func display() { // only subclass have overridden method
        super.display() // to call parent class properties
        
        print("vacation weeks :", vacationweeks!)
    }
}

//object
var obj2 = permanentemployee()
obj2.empID = 134
obj2.empName = "JONTY"
obj2.basicPay = 234567
obj2.vacationweeks = 20
obj2.display()

print("..............................")
var emp3 = employee()
emp3.display()

print("..............................")
var emp4 = employee(ID: 104, nm: "kiran", pay: 9000)
emp4.display()

//object of permanent class for default initailizer
print("..............................")
var obj3 = permanentemployee()
obj3.display()

print("..............................")

//object of permanent class for  initailizer
print("..............................")
var obj4 = permanentemployee()
obj4.display()
print("..............................")

//third clas

class payroll : permanentemployee{
    var finalpayroll : Double?
    //default intializer
    override init() {
        super.init()
        self.finalpayroll = 0
    }
    
    override init(eID: Int, enm: String, epay: Double, evw: Int){
        super.init(eID : eID, enm : enm, epay : epay,evw : evw)
        self.finalpayroll = 0
        if(evw > 5)
        {
            self.finalpayroll! = self.basicPay! - 100
        }
        else{
            self.finalpayroll! = self.basicPay!
        }
    }
    override func display() {
         super.display()
        print("total pay: ",self.finalpayroll!)
    }
    
    
}

var emp6 =  payroll(eID: 120, enm: "potter", epay: 7666,evw: 8 )
emp6.display()


//


/*
class Payroll : permanentemployee{
    var finalpayroll : Double?{
        
        get{
            var evw = self.vacationweeks!
            if(evw > 5)
            {
                return self.basicPay!
            }
            else{
                return self.basicPay!
            }
        }
    }
    
}
*/
print("..............................")

//manipulate object array
var janpayroll = [payroll]()
let noOfEmployees = 2

for i in 0..<2{
    janpayroll.append(payroll(eID: 111, enm: "HARRY", epay: 9555, evw: 7))
    janpayroll[i].display()
}







