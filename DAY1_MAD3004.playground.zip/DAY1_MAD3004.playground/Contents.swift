//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
///use print
print(str)

//terminator is used ending line with some thing
print("this is string: \(str)",terminator:" ")

//use separator for spacing betweem multiple prompts
print("1","2","3","4","5",separator:"-")

var n1=10
print("number1",n1,str)

var n2=20
print("number2 :" ,n2)

var sum=n1+n2
print("sum is :",sum)
print("sum=",n1+n2)

/*
 //
 first declare will go on till the end u cant change the datatype
n1="test"
print("n1:",n1)
*/

var a:Int=10
print("a=",a)

var greet:String="good morning"
print("greet string :",greet)

var n3:Float=45.78
print("float:",n3)

var n4:Double=3456789.34567890456
print("double:",n4)

//use ctrl+window+space for emoji on windows
//use ctrl+cmd+space om mac
var emoji="👻";
print("its a \(emoji) hour")
print(emoji)

let 👻="bhoota"
print(👻)

let pi=3.14
//pi=567.67
print("pi:",pi)

//var pi=10;

//optionalpractice
let mynum:Int? //optional value
mynum = 10

if mynum != nil {
    print("mynum :", mynum!)//by putting exclamation sign we are wrapping it,without that it is optional
}
else{
    print("mynum is nil")
}
 let possiblenumber="yu"
let convertednumber:Int?
convertednumber = Int(possiblenumber)
if convertednumber != nil{
    print("converted Number:",convertednumber!)
}
else
{
    print("converted number is nil")
}

//for loop
for i  in 1..<5{
    print("i = ",i)//use three dots if u dont wanna put sign
}

//array
let language:[String]// for declaring array use square brackets
language = ["english","spanish","french"]

for i in language {
    print("language : ",i)
}


let numbers:[Int]
numbers = [1,2,3,4]

for i in numbers{
    print("number" , i)
    
}

//stride function
var interval:Int=5
for i in stride(from :00, to: 50, by: interval){
    print(i," ",terminator: " ")
}

//use of for_ in is values used for iteration not having memory so saving of memory is hapening
var answer:Int = 1
for _ in 1...5{
    answer *= 5
}
print("answer:",answer)


//while
var j = 1
while (j<5){
   
print("value of j is \(j)")
j = j + 1
}

//repeat and while that is do while
j = 5
repeat{
    print("repeat :",j)
    j=j+2
}
while(j<=10)


//task
var n=1
var n5:Int=11
if n5<10{
    for m in 1...10{
        n = m*5
        print(n)
    }
}
else if(n5>10)
{
    var fact=1
    for i in 1...5{
    fact=fact*i
}
print(fact)
}



//switch case
var num1 = 100
switch num1 {
case 100:
    print("value of num is 100")
    fallthrough
case 10,15:
    print("value is 10 or 15")
case 5:
    print("value is 5")
default:
    print("default case")
}
