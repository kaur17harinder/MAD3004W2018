//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
print(str)

//closures in swift

//sorted closure
 var months = [1,4,9,3,8,2]
print(months.sorted())

func reverse(_ s1: Int, _ s2: Int) -> Bool{
    return s1 > s2
}

var reversedmonths = months.sorted(by: reverse)
print("reversed months:",reversedmonths)

func increasing(_ s1: Int , _ s2: Int) -> Bool{
    return s1 < s2
}

var increasingmonths = months.sorted(by: increasing)
print("increasing months:", increasingmonths)

/*closure expression syntax
{
    (parameters),return type in statements
}
*/
var reverseclosure = months.sorted(by: {
    (s1: Int, s2: Int) -> Bool in
    return s1 > s2
})
print("reverse closure:",reverseclosure)


//inferring parameters types from context
var inferTypes = months.sorted(by: {
    //(s1,s2) in return s1 < s2
    (s1, s2) in s1 < s2 //implicit return
    
})
print("infertypes", inferTypes)

//shorthand argument names
print("shorthand argument:",months.sorted(by: {$0 < $1}))

//operator methods
print("operator methods" , months.sorted(by: < ))

var three = [1,3,4,5,6,7,12,23,45]
print("three:",three)

var modthree = three.filter({ $0 % 3 == 0})
print("modthree:",modthree)

var eventhree = three.filter({ $0 % 2 == 0})
print("eventhree:",eventhree)

var oddthree = three.filter({ $0 % 2 != 0})
print("oddthree:",oddthree)



//nested functions closure

func makeincrementer(forincrement amount: Int) ->  () -> Int { //returning function prototype
    var runningTotal = 0
    func incrementer() -> Int{
        runningTotal += amount
        return runningTotal
    }
    return incrementer //returning a function
}

let incrementByTen = makeincrementer(forincrement: 10)
print("first call : ",incrementByTen())
print("second call : ",incrementByTen())
print("third call : ",incrementByTen())



let incrementBySeven = makeincrementer(forincrement: 7)
print("first call of 7: " , incrementBySeven())
print("second call of 7: " , incrementBySeven())
print("third call of 7: " , incrementBySeven())

print("fourth call of 10: " , incrementByTen())


//closures are reference type
let incrementBySevenAgain = incrementBySeven
print("first call of 7again: " , incrementBySevenAgain())

//Autoclosures delays the evaluation
var errorList = [404,414,402,431,455,440]
print("total errors :" , errorList.count)

let debugger = {errorList.remove(at: 0)}
print("total errors :" , errorList.count)
//until or unless we are not calling that let constant that cannot be removed we have to call that constant

print("now solving \(debugger())!")
print("total errors:",errorList.count)
print("error list:",errorList)

/*
 */
//You get the same behavior of delayed evaluation when you pass a closure as an argument to a function.
func solve(error debugger: @autoclosure () -> Int){
    print("now solving \(debugger())!")
    
}
solve(error: errorList.remove(at: 0))
print("error list:",errorList)

//escaping closures
var completionHandlers: [() -> Void] = []
func someFunctionWithEscapingClosure(completionHandler: @escaping () -> Void) {
    completionHandlers.append(completionHandler)
}


//
func someFunctionWithNonescapingClosure(closure: () -> Void) {
    closure()
}

class SomeClass {
    var x = 10
    func doSomething() {
        someFunctionWithEscapingClosure { self.x = 100 }
        someFunctionWithNonescapingClosure { x = 200 }
    }
}

let instance = SomeClass()
instance.doSomething()
print(instance.x)
// Prints "200"

completionHandlers.first?()
print(instance.x)
// Prints "100"






